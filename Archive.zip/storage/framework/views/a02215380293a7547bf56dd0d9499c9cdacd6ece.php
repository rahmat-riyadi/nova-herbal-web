<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card card-custom">
        <div class="card-body">

            <h3 class="card-label">Daftar Pasien</h3>

            <?php if(session()->has('message')): ?>
                <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <ul class="nav nav-tabs nav-bold nav-tabs-line mb-2">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#all_patient">
                        <span class="nav-icon"><i class="flaticon2-avatar" ></i></span>
                        Semua
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#current_patient">
                        <span class="nav-icon"><i class="flaticon2-user" ></i></span>
                        Hari Ini
                    </a>
                </li>
            </ul>

            
            <!--begin: Datatable-->
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="all_patient" role="tabpanel" aria-labelledby="all_patient">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('patients-table')->html();
} elseif ($_instance->childHasBeenRendered('kOwVod7')) {
    $componentId = $_instance->getRenderedChildComponentId('kOwVod7');
    $componentTag = $_instance->getRenderedChildComponentTagName('kOwVod7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('kOwVod7');
} else {
    $response = \Livewire\Livewire::mount('patients-table');
    $html = $response->html();
    $_instance->logRenderedChild('kOwVod7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="tab-pane fade" id="current_patient" role="tabpanel" aria-labelledby="current_patient">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('current-patient-table')->html();
} elseif ($_instance->childHasBeenRendered('rYTCs9y')) {
    $componentId = $_instance->getRenderedChildComponentId('rYTCs9y');
    $componentTag = $_instance->getRenderedChildComponentTagName('rYTCs9y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rYTCs9y');
} else {
    $response = \Livewire\Livewire::mount('current-patient-table');
    $html = $response->html();
    $_instance->logRenderedChild('rYTCs9y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
            <!--end: Datatable-->
        </div>
    </div>

</div>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>

<script>

    const handleDeletePatient = () => {

        const id = document.querySelector('.delete-patient').getAttribute('data-id')
        const form = document.querySelector('.delete-patient-form')
        form.action = `/admin/patient/delete/${id}`
        form.submit()

    }

</script>
    
<?php $__env->stopPush(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/admin/patient/index.blade.php ENDPATH**/ ?>