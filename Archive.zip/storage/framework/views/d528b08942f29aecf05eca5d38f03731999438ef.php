<div class="alert alert-custom alert-notice alert-light-primary fade show mt-1" role="alert" style="background-color: rgba(0, 120, 93, 0.1);" >
    <div class="alert-text"><?php echo e(session($message ?? 'message')); ?></div>
    <div class="alert-close">
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <span aria-hidden="true"><i class="ki ki-close"></i></span>
        </button>
    </div>
</div><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/components/alert.blade.php ENDPATH**/ ?>