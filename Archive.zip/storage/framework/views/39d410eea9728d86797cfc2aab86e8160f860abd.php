<?php $__env->startSection('content'); ?>

<div class="container">
    <!--begin::Dashboard-->

    <div class="row">

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('total-patient-card')->html();
} elseif ($_instance->childHasBeenRendered('4Opftaq')) {
    $componentId = $_instance->getRenderedChildComponentId('4Opftaq');
    $componentTag = $_instance->getRenderedChildComponentTagName('4Opftaq');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('4Opftaq');
} else {
    $response = \Livewire\Livewire::mount('total-patient-card');
    $html = $response->html();
    $_instance->logRenderedChild('4Opftaq', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('monthly-patient-card')->html();
} elseif ($_instance->childHasBeenRendered('KuJwlpu')) {
    $componentId = $_instance->getRenderedChildComponentId('KuJwlpu');
    $componentTag = $_instance->getRenderedChildComponentTagName('KuJwlpu');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KuJwlpu');
} else {
    $response = \Livewire\Livewire::mount('monthly-patient-card');
    $html = $response->html();
    $_instance->logRenderedChild('KuJwlpu', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('current-patient-card')->html();
} elseif ($_instance->childHasBeenRendered('SVlFVLI')) {
    $componentId = $_instance->getRenderedChildComponentId('SVlFVLI');
    $componentTag = $_instance->getRenderedChildComponentTagName('SVlFVLI');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('SVlFVLI');
} else {
    $response = \Livewire\Livewire::mount('current-patient-card');
    $html = $response->html();
    $_instance->logRenderedChild('SVlFVLI', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    </div>

    <!--begin::Row-->
    <div class="row">
        <div class="col">
            <!--begin::Advance Table Widget 10-->
            <div class="card card-custom gutter-b card-stretch">
                <!--begin::Body-->
                <div class="card-body py-0">

                    <?php if(session()->has('message')): ?>
                        <?php echo $__env->make('components.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?>

                    <div class="d-flex pb-5 pt-10">
                        <h3 class="card-label">Daftar Pasien Hari Ini</h3>
                    </div>

                    <!--begin::Table-->
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('current-patient-table')->html();
} elseif ($_instance->childHasBeenRendered('PiE4ZIn')) {
    $componentId = $_instance->getRenderedChildComponentId('PiE4ZIn');
    $componentTag = $_instance->getRenderedChildComponentTagName('PiE4ZIn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('PiE4ZIn');
} else {
    $response = \Livewire\Livewire::mount('current-patient-table');
    $html = $response->html();
    $_instance->logRenderedChild('PiE4ZIn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <!--end::Table-->
                </div>
                <!--end::Body-->
            </div>
            <!--end::Advance Table Widget 10-->
        </div>
    </div>
    <!--end::Row-->
    <!--end::Dashboard-->
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/admin/index.blade.php ENDPATH**/ ?>