<?php $__env->startSection('content'); ?>

<div class="container">
    <!--begin::Dashboard-->

    <div class="row">

        <div class="col-4">
            <div class="card rounded-lg card-custom bgi-no-repeat card-stretch gutter-b" style="background-position: right bottom; background-size: 40% auto; background-image: url(<?php echo e(asset('assets/icons/card-bg.svg')); ?>)">
                <!--begin::Body-->
                <div class="card-body my-4 py-6">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <p class="font-weight-bolder font-size-h2 m-0 ">8.972</p>
                            <p class="font-weight-bold m-0 mt-1" >Total Semua Pasien</p>
                        </div>
                        <img style="height:60px;"  src="<?php echo e(asset('assets/icons/people.svg')); ?>" alt="">
                    </div>
                </div>
                <!--end::Body-->
            </div>
        </div>
        <div class="col-4">
            <div class="card rounded-lg card-custom bgi-no-repeat card-stretch gutter-b" style="background-position: right bottom; background-size: 40% auto; background-image: url(<?php echo e(asset('assets/icons/card-bg.svg')); ?>)">
                <!--begin::Body-->
                <div class="card-body my-4 py-6">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <p class="font-weight-bolder font-size-h2 m-0 ">127</p>
                            <p class="font-weight-bold m-0 mt-1" >Total Pasien Bulan Ini</p>
                        </div>
                        <img style="height:60px;"  src="<?php echo e(asset('assets/icons/profile2user.svg')); ?>" alt="">
                    </div>
                </div>
                <!--end::Body-->
            </div>
        </div>

        <div class="col-4">
            <div class="card rounded-lg card-custom bgi-no-repeat card-stretch gutter-b" style="background-position: right bottom; background-size: 40% auto; background-image: url(<?php echo e(asset('assets/icons/card-bg.svg')); ?>)">
                <!--begin::Body-->
                <div class="card-body my-4 py-6">
                    <div class="d-flex align-items-center justify-content-between">
                        <div>
                            <p class="font-weight-bolder font-size-h2 m-0 ">5</p>
                            <p class="font-weight-bold m-0 mt-1" >Total Pasien Hari Ini</p>
                        </div>
                        <img style="height:60px;"  src="<?php echo e(asset('assets/icons/profile.svg')); ?>" alt="">
                    </div>
                </div>
                <!--end::Body-->
            </div>
        </div>

    </div>

    <!--begin::Row-->
    <div class="row">
        <div class="col">
            <!--begin::Advance Table Widget 10-->
            <div class="card card-custom gutter-b card-stretch">
                <!--begin::Body-->
                <div class="card-body py-0">

                    <div class="d-flex pb-5 pt-10">
                        <h3 class="card-label">Daftar Pasien Hari Ini</h3>
                    </div>

                    <!--begin::Table-->
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('patients-table')->html();
} elseif ($_instance->childHasBeenRendered('02DPueo')) {
    $componentId = $_instance->getRenderedChildComponentId('02DPueo');
    $componentTag = $_instance->getRenderedChildComponentTagName('02DPueo');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('02DPueo');
} else {
    $response = \Livewire\Livewire::mount('patients-table');
    $html = $response->html();
    $_instance->logRenderedChild('02DPueo', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                    <!--end::Table-->
                </div>
                <!--end::Body-->
            </div>
            <!--end::Advance Table Widget 10-->
        </div>
    </div>
    <!--end::Row-->
    <!--end::Dashboard-->
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/index.blade.php ENDPATH**/ ?>