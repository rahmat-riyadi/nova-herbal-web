<?php if($paginator->hasPages()): ?>


    <ul class="pagination-comp" >


        <?php if($paginator->onFirstPage()): ?>
            <li class="pagination-item " aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                <span class="pagination-link icon" aria-hidden="true">
                    <img src="<?php echo e(asset('assets/icons/double-left.svg')); ?>" alt="">
                </span>
            </li>
            <li class="pagination-item" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                <span class="pagination-link icon" aria-hidden="true">
                    <img src="<?php echo e(asset('assets/icons/left.svg')); ?>" alt="">
                </span>
            </li>
        <?php else: ?>
            <li class="pagination-item ">
                <a class="pagination-link icon" href="<?php echo e($paginator->url(1)); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <img src="<?php echo e(asset('assets/icons/double-left.svg')); ?>" alt="">
                </a>
            </li>
            <li class="pagination-item">
                <a class="pagination-link icon" href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <img src="<?php echo e(asset('assets/icons/left.svg')); ?>" alt="">
                </a>
            </li>
        <?php endif; ?>

        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            
            <?php if(is_string($element)): ?>
                <li class="pagination-item disabled" aria-disabled="true"><span class="pagination-link"><?php echo e($element); ?></span></li>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <li class="pagination-item " aria-current="page"><span class="pagination-link active"><?php echo e($page); ?></span></li>
                    <?php else: ?>
                        <li class="pagination-item"><a class="pagination-link" href="<?php echo e($url); ?>"><?php echo e($page); ?></a></li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($paginator->hasMorePages()): ?>
            <li class="pagination-item">
                <a class="pagination-link icon" href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <img src="<?php echo e(asset('assets/icons/right.svg')); ?>" alt="">
                </a>
            </li>
            <li class="pagination-item">
                <a class="pagination-link icon" href="<?php echo e($paginator->url(ceil($paginator->total()/$paginator->perPage()))); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <img src="<?php echo e(asset('assets/icons/double-right.svg')); ?>" alt="">
                </a>
            </li>
        <?php else: ?>
            <li class="pagination-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                <span class="pagination-link" aria-hidden="true"><img src="<?php echo e(asset('assets/icons/right.svg')); ?>" alt=""></span>
            </li>
            <li class="pagination-item disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                <span class="pagination-link" aria-hidden="true"><img src="<?php echo e(asset('assets/icons/double-right.svg')); ?>" alt=""></span>
            </li>
        <?php endif; ?>

    </ul>

<?php endif; ?>
<?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/components/pagination.blade.php ENDPATH**/ ?>