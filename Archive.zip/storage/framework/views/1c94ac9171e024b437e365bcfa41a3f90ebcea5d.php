<?php $__env->startSection('content'); ?>

<div class="container">
    <form action="<?php echo e(empty($user) ? route('storeAdmin') : 'admin/admin/update/'. $user['id']); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="card card-custom">
            <div class="card-header flex-wrap border-0 py-6 pb-0">
                <div class="card-title">
                    <h3 class="card-label">Tambah Admin
                </div>
                <div class="card-toolbar">
                    <!--begin::Button-->
                    <a href="/admin/admin" class="btn btn-secondary font-weight-bolder mr-5">Kembali</a>
                    <button type="submit"  class="btn btn-primary font-weight-bolder">Simpan</button>
                    <!--end::Button-->
                </div>
            </div>
            <div class="card-body">
                <div class="form-group row">
                    <label class="col-lg-2 col-form-label">Nama:</label>
                    <div class="col-lg-6">
                        <input type="text" name="name" value="<?php echo e($user['name'] ?? ''); ?>" class="form-control" placeholder="Masukkan Nama"/>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-2 col-form-label">Email:</label>
                    <div class="col-lg-6">
                        <input type="text" name="email" value="<?php echo e($user['email'] ?? ''); ?>" class="form-control" placeholder="Masukkan Email"/>
                    </div>
                </div>

                <?php if(empty($user)): ?>
                    <div class="form-group row">
                        <label class="col-lg-2 col-form-label">Kata Sandi:</label>
                        <div class="col-lg-6">
                            <input type="text" name="password" value="<?php echo e($user['password'] ?? ''); ?>" class="form-control" placeholder="Masukkan Kata Sandi"/>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-2 col-form-label">Konfirmasi Kata Sandi:</label>
                        <div class="col-lg-6">
                            <input type="text" name="confirm_password" value="<?php echo e($user['confirm_password'] ?? ''); ?>" class="form-control" placeholder="Konfirmasi Kata Sandi"/>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="form-group row">
                    <label class="col-lg-2 col-form-label">Role</label>
                    <div class="col-lg-6 col-form-label">
                        <div class="radio-inline">
                            <label class="radio radio-outline radio-primary">
                                <input value="admin" type="radio" name="role" <?php echo e(!empty($user['role']) ?  $user['role'] == 'admin' ? 'checked' : '' : ''); ?> />
                                <span></span>
                                Admin
                            </label>
                            <label class="radio radio-outline radio-primary">
                                <input value="superadmin" type="radio" name="role" <?php echo e(!empty($user['role']) ?  $user['role'] == 'superadmin' ? 'checked' : '' : ''); ?>  />
                                <span></span>
                                Super Admin
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/ismut-web/resources/views/admin/admin/form.blade.php ENDPATH**/ ?>