<div 
    class="subheader py-5 py-lg-15 gutter-b subheader-transparent" 
    id="kt_subheader"
    <?php if(Route::current()->getName() == 'createPatient'): ?>
        style="background-color: #00785D; background-position: center bottom; background-repeat: no-repeat; background-image: url(<?php echo e(asset('assets/icons/form-pattern.svg')); ?>); min-height: 25vh; max-height: 25vh;"
    <?php else: ?>
        style="background-color: #00785D; background-position: center bottom; background-size: 100% 100%; background-repeat: no-repeat; background-image: url(<?php echo e(asset('assets/img/subheader.png')); ?>); min-height: 25vh; max-height: 25vh;"
    <?php endif; ?>
>
    <div class="container d-flex flex-column">
        <!--begin::Title-->

        <?php if(Route::current()->getName() == 'createPatient'): ?>

            <h2 class="m-auto" style="color: #FECA37;" >
                Tambah Pasien
            </h2>

        <?php else: ?>
            
            <?php if(Str::contains(Route::current()->getName(), 'patient')): ?>
            <div class="d-flex align-items-sm-end flex-column flex-sm-row mb-5">
                <h2 class="text-white mr-5 mb-0">
                    Daftar Pasien
                </h2>
            </div>
            <?php endif; ?>
            <!--end::Title-->
            <!--begin::Search Bar-->
            <?php if(!Str::contains(Request::url(), 'show')): ?>
            <div class="d-flex justify-content-between align-items-md-center mb-2 flex-column flex-md-row">

                <?php if(Str::contains(Route::current()->getName(), 'dashboard')): ?>
                    <div>
                        <p style="color: #FECA37; font-weight: 400 !important;" class="font-size-h6 mb-2" >Halo, <?php echo e(auth()->user()->name); ?></p>
                        <p style="font-weight: 700 !important; line-height: 28px; font-family: 'Quicksand' !important;" class="text-white m-0 font-weight-bolder font-size-h2">
                            Selamat Datang
                            <br>
                            Sistem Manajemen Pasien
                        </p>
                    </div>
                <?php else: ?>
                <div class="bg-white rounded p-2 d-flex flex-grow-1 flex-sm-grow-0" style="min-width: 440px;">
                    <!--begin::Form-->
                    <form class="form d-flex align-items-md-center flex-sm-row flex-column flex-grow-1">
                        <!--begin::Input-->
                        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search-input')->html();
} elseif ($_instance->childHasBeenRendered('snuiHDH')) {
    $componentId = $_instance->getRenderedChildComponentId('snuiHDH');
    $componentTag = $_instance->getRenderedChildComponentTagName('snuiHDH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('snuiHDH');
} else {
    $response = \Livewire\Livewire::mount('search-input');
    $html = $response->html();
    $_instance->logRenderedChild('snuiHDH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                        <!--end::Input-->
                    </form>
                    <!--end::Form-->
                </div>
                <?php endif; ?>
                <!--begin::Advanced Search-->
                <?php if(Str::contains(Route::current()->getName(), 'patient')): ?>
                <div class="mt-4 my-md-0">
                    <a href="/admin/<?php echo e(Route::current()->getName()); ?>/create" style="background-color: #FECA37; border: none;" class="btn font-weight-bold btn-hover-light-dark mt-3 mt-sm-0 px-4">
                        <i class="flaticon2-add-1 text-dark icon-nm mr-1" ></i>
                        Tambah Pasien
                    </a>
                </div>
                <?php endif; ?>
                <!--end::Advanced Search-->
            </div>
            <?php else: ?>
            
            <?php endif; ?>

        <?php endif; ?>

        <!--end::Search Bar-->
    </div>
</div><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/partials/subheader.blade.php ENDPATH**/ ?>