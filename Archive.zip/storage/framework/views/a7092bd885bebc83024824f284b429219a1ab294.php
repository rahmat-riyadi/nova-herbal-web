<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card card-custom">
        <div class="card-body">

            <h3 class="card-label">Daftar Pasien</h3>

            <ul class="nav nav-tabs nav-bold nav-tabs-line mb-2">
                <li class="nav-item">
                    <a class="nav-link active" data-toggle="tab" href="#all_patient">
                        <span class="nav-icon"><i class="flaticon2-avatar" ></i></span>
                        Semua
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" data-toggle="tab" href="#current_patient">
                        <span class="nav-icon"><i class="flaticon2-user" ></i></span>
                        Hari Ini
                    </a>
                </li>
            </ul>

            <?php if(session()->has('success')): ?>
            <div class="alert alert-custom alert-notice alert-light-primary fade show" role="alert">
                <div class="alert-icon"><i class="flaticon-warning"></i></div>
                <div class="alert-text"><?php echo e(session('success')); ?></div>
                <div class="alert-close">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true"><i class="ki ki-close"></i></span>
                    </button>
                </div>
            </div>
            <?php endif; ?>
            <!--begin: Datatable-->
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="all_patient" role="tabpanel" aria-labelledby="all_patient">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('patients-table')->html();
} elseif ($_instance->childHasBeenRendered('LLvf8eJ')) {
    $componentId = $_instance->getRenderedChildComponentId('LLvf8eJ');
    $componentTag = $_instance->getRenderedChildComponentTagName('LLvf8eJ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LLvf8eJ');
} else {
    $response = \Livewire\Livewire::mount('patients-table');
    $html = $response->html();
    $_instance->logRenderedChild('LLvf8eJ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
                <div class="tab-pane fade" id="current_patient" role="tabpanel" aria-labelledby="current_patient">
                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('current-patient-table')->html();
} elseif ($_instance->childHasBeenRendered('jqjoQu9')) {
    $componentId = $_instance->getRenderedChildComponentId('jqjoQu9');
    $componentTag = $_instance->getRenderedChildComponentTagName('jqjoQu9');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jqjoQu9');
} else {
    $response = \Livewire\Livewire::mount('current-patient-table');
    $html = $response->html();
    $_instance->logRenderedChild('jqjoQu9', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                </div>
            </div>
            <!--end: Datatable-->
        </div>
    </div>

</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/patient/index.blade.php ENDPATH**/ ?>