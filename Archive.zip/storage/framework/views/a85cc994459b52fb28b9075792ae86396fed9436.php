<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="staticBackdrop" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h5 class="modal-title text-white" id="exampleModalLabel">Tambah Obat</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="flaticon2-cross text-warning"></i>
                </button>
            </div>
            <div class="modal-body">
                <form wire:submit.prevent="store">

                    <input type="hidden" wire:model="patients_id" value="<?php echo e($patient->id); ?>" >

                    <div class="form-group">
                        <label>Tanggal </label>
                        <input type="date" wire:model="coming_time" class="form-control form-control-solid"/>
                        <?php $__errorArgs = ['coming_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="form-text text-muted text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                        <label for="exampleTextarea">Obat</label>
                        <textarea wire:model="medicine" class="form-control form-control-solid" rows="3"></textarea>
                        <?php $__errorArgs = ['medicine'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="form-text text-muted text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="d-flex">
                        <div class="form-group flex-grow-1 mr-5">
                            <label>Warna Kapsul</label>
                            <input type="text" wire:model="capsul_color" class="form-control form-control-solid"/>
                            <?php $__errorArgs = ['capsul_color'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="form-text text-muted text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="form-group flex-grow-1">
                            <label>Nominal <?php echo e($num); ?></label>
                            <input type="number" wire:model="price" class="form-control form-control-solid"/>
                            <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="form-text text-muted text-danger"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="d-flex">
                        <button type="button" wire:click="add" style="background-color: #FECA37;" class="btn font-weight-bold">Simpan</button>
                        <button type="button" class="btn btn-outline-dark font-weight-bold ml-5" data-dismiss="modal">Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div><?php /**PATH /Users/rahmat-riyadi/Work Area/Laravel/nova-herbal/resources/views/livewire/medicine-modal.blade.php ENDPATH**/ ?>