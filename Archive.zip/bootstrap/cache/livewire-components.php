<?php return array (
  'current-patient-card' => 'App\\Http\\Livewire\\CurrentPatientCard',
  'current-patient-table' => 'App\\Http\\Livewire\\CurrentPatientTable',
  'disease-table' => 'App\\Http\\Livewire\\DiseaseTable',
  'history-table' => 'App\\Http\\Livewire\\HistoryTable',
  'lab-result-table' => 'App\\Http\\Livewire\\LabResultTable',
  'medicine-panel' => 'App\\Http\\Livewire\\MedicinePanel',
  'monthly-patient-card' => 'App\\Http\\Livewire\\MonthlyPatientCard',
  'patient-note' => 'App\\Http\\Livewire\\PatientNote',
  'patients-table' => 'App\\Http\\Livewire\\PatientsTable',
  'search-input' => 'App\\Http\\Livewire\\SearchInput',
  'total-patient-card' => 'App\\Http\\Livewire\\TotalPatientCard',
);